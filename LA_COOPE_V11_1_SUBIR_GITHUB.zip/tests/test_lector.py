from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'scripts'))
import actualizar_fcf as f

TEAM={'id':'amateur-a','name':'Amateur A','division':'Primera Catalana','group':'3','category':'Amateur'}
BASE='https://www.fcf.cat/resultats/2627/futbol-11/primera-catalana/grup-3'
ACT='https://www.fcf.cat/ca/competicio/acta/12345678'
HTML_RESULTS='''<html><body><h1>Competició | TEMPORADA 2026-2027</h1>
<h2>primera catalana | grup 3 | Jornada 8</h2><div class="match">
<a href="/clubs/el-catllar">EL CATLLAR, C.E. A</a>
<a href="/ca/competicio/acta/12345678">ACTA TANCADA 1 - 2</a>
<a href="/clubs/coop">CIUDAD COOPERATIVA, C.F. A</a></div></body></html>'''
HTML_ACT='''<html><body><h1>Acta del partit</h1><div>MARTORELL C.F.</div><div>Acta Tancada</div><div>5-2</div>
<div>CIUDAD COOPERATIVA, C.F.</div><span>COMPETICIÓ/PRIMERA DIVISIÓ ALEVÍ S11/GRUP 8/Jornada 3</span>
<span>Temporada : 2026 / 27</span><div>Data: 11.10.2026</div><p>5 - 2 GOL 60</p></body></html>'''
HTML_CLASS='''<html><body><p>Competició | TEMPORADA 2026-2027</p><h1>primera catalana | grup 3</h1>
<table><tr><th>#</th><th>Equip</th><th>PJ</th><th>Pts</th></tr>
<tr><td>1</td><td>Santfeliuenc, F.C. A</td><td>8</td><td>22</td></tr>
<tr><td>2</td><td>Bon Pastor A</td><td>8</td><td>16</td></tr>
<tr><td>9</td><td>CIUDAD COOPERATIVA, C.F. A</td><td>7</td><td>11</td></tr></table></body></html>'''
HTML_CAL='''<html><body><h1>TEMPORADA 2026-2027</h1><h2>primera catalana | grup 3</h2>
<div class="fixture"><a href="/equips/coop">CIUDAD COOPERATIVA, C.F. A</a><span>14.11.2026</span>
<a href="/equips/asco">ASCÓ, F.C. A</a><span>18:15</span></div></body></html>'''

class TestFCF(unittest.TestCase):
    def test_validate_season(self):
        self.assertEqual(f.season_number('2026/27'),2026)
        self.assertEqual(f.season_number('2027/28'),2027)
        self.assertIsNone(f.season_number('2026/28'))
        self.assertTrue(f.html_is_season(HTML_RESULTS,2026))
        self.assertFalse(f.html_is_season(HTML_RESULTS,2027))
    def test_context(self):
        self.assertTrue(f.page_context_matches(HTML_RESULTS,TEAM,2026))
        self.assertFalse(f.page_context_matches(HTML_RESULTS,{**TEAM,'group':'2'},2026))
        self.assertFalse(f.page_context_matches(HTML_RESULTS,TEAM,2027))
    def test_cards(self):
        self.assertEqual(f.candidate_score_cards(HTML_RESULTS,BASE),{ACT:'1-2'})
    def test_acta(self):
        t={'id':'alevin-s11-a','group':'8','division':'Alevi Primera S11'}
        g=f.acta_from_html(HTML_ACT,ACT,2026,t)
        self.assertIsNotNone(g)
        self.assertEqual(g['score'],'5-2')
        self.assertEqual(g['date'],'2026-10-11')
        self.assertIsNone(f.acta_from_html(HTML_ACT,ACT,2027,t))
        self.assertIsNone(f.acta_from_html(HTML_ACT,ACT,2026,{**t,'group':'7'}))
    def test_standings(self):
        vals=f.extract_standings(HTML_CLASS)
        self.assertEqual(len(vals),3)
        self.assertEqual(vals[-1]['points'],11)
    def test_future(self):
        x=f.candidate_fixture_cards(HTML_CAL,BASE,2026)
        self.assertEqual(len(x),1)
        self.assertEqual(x[0]['date'],'2026-11-14')
    def test_no_unofficial_url(self):
        self.assertFalse(f.valid_official_url('https://fcf.cat.attacker.com/acta'))
        self.assertFalse(f.valid_official_url('http://www.fcf.cat/acta'))
    def test_keep_old_if_offline(self):
        class Offline:
            cache={};errors=[]
            def get(self,url):return None
            def render(self,url):return None
        old={'schema':1,'source':'fcf.cat','season':'2026/27','confirmed':True,
             'officialEvidence':['https://www.fcf.cat/ca/noticies-fcf/1037023'],
             'snapshots':{'amateur-a':{'results':[{'date':'2026-11-08','home':'A','away':'CIUDAD COOPERATIVA','score':'1-2','status':'final','url':ACT}]}}}
        result=f.update(old,[TEAM],Offline(),f.date(2027,8,1),True)
        self.assertEqual(result['season'],'2026/27')
        self.assertTrue(result['snapshots']['amateur-a']['results'])

if __name__=='__main__':unittest.main()

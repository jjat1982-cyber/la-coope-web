package com.lacoope.santboi;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.widget.Toast;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private String site;
    private String siteHost;
    private String sitePath;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,19,16));
        getWindow().setNavigationBarColor(Color.rgb(16,19,16));
        try(InputStream in=getAssets().open("site-url.txt")){
            site=new String(in.readAllBytes(),StandardCharsets.UTF_8).trim();
            Uri u=Uri.parse(site);
            if(!"https".equals(u.getScheme())||u.getHost()==null||!u.getHost().endsWith("github.io"))throw new IllegalArgumentException("URL de Pages incorrecta");
            siteHost=u.getHost();sitePath=u.getPath();
        }catch(Exception e){
            Toast.makeText(this,"No se configuró la web LA COOPE",Toast.LENGTH_LONG).show();finish();return;
        }
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(16,19,16));
        WebSettings st=web.getSettings();st.setJavaScriptEnabled(true);st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false);st.setAllowContentAccess(false);st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        st.setBuiltInZoomControls(false);st.setDisplayZoomControls(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
          @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){
             Uri u=req.getUrl();
             if("https".equals(u.getScheme())&&siteHost.equals(u.getHost())&&u.getPath()!=null&&u.getPath().startsWith(sitePath))return false;
             if("https".equals(u.getScheme())&&("www.fcf.cat".equals(u.getHost())||"fcf.cat".equals(u.getHost()))){startActivity(new Intent(Intent.ACTION_VIEW,u));return true;}
             if("https".equals(u.getScheme())){startActivity(new Intent(Intent.ACTION_VIEW,u));return true;}
             return true;
          }
          @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err){
             if(req.isForMainFrame())Toast.makeText(MainActivity.this,"No hay conexión con LA COOPE. Reintenta cuando tengas internet.",Toast.LENGTH_LONG).show();
          }
        });
        setContentView(web);web.loadUrl(site);
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}

#!/usr/bin/env python3
"""Lector público FCF de LA COOPE. No intenta eludir bloqueos ni usar endpoints privados.

Lee HTML oficial visible sin iniciar sesión. Publica únicamente partidos cuyos detalles
puede contrastar en un acta pública (marcador y fecha) y clasificaciones explícitas.
Si la FCF cambia de HTML o bloquea peticiones, preserva los últimos datos válidos.
"""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, date, timezone
import json
import os
from pathlib import Path
import re
import time
import unicodedata
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup, Tag

ROOT = Path(__file__).resolve().parents[1]
FEED = ROOT / 'site' / 'feed.json'
TEAMS = ROOT / 'site' / 'teams.json'
DIAG = ROOT / 'site' / 'diagnostico.json'
ORIGIN = 'https://www.fcf.cat'
CLUB_RE = re.compile(r'\b(?:ciudad|ciutat)\s+cooperativa\b', re.I)
SCORE_RE = re.compile(r'\b(\d{1,2})\s*[-–:]\s*(\d{1,2})\b')
DATE_RE = re.compile(r'\b(\d{1,2})[./-](\d{1,2})[./-](20\d{2})\b')
SEASON_RE = re.compile(r'(?:TEMPORADA|Temporada)\s*:?\s*(20\d{2})\s*[/\-]\s*(20)?(\d{2})', re.I)
GROUP_RE = re.compile(r'GRUP(?:O)?\s*(\d{1,2})', re.I)
COMP_RE = re.compile(r'COMPETICI[ÓO]N?\s*/\s*([^/]{4,120})\s*/\s*GRUP\s*(\d{1,2})', re.I)
# Las rutas oficiales comprobadas en el índice FCF usan /resultats/2425/...
# La FCF también conserva URL de actas numéricas en /ca/competicio/acta/...
DIV_SLUGS = {
  'amateur-a': ('futbol-11','primera-catalana'),
  'amateur-b': ('futbol-11','quarta-catalana'),
  'juvenil-a': ('futbol-11','juvenil-primera-divisio'),
  'juvenil-b': ('futbol-11','juvenil-segona-divisio'),
  'cadete-s16-a': ('futbol-11','cadet-primera-divisio-s16'),
  'cadete-s16-b': ('futbol-11','cadet-segona-divisio-s16'),
  'cadete-s15-a': ('futbol-11','cadet-primera-divisio-s15'),
  'infantil-s14-a': ('futbol-11','infantil-primera-divisio-s14'),
  'infantil-s13-a': ('futbol-11','infantil-primera-divisio-s13'),
  'infantil-s13-b': ('futbol-11','infantil-segona-divisio-s13'),
  'alevin-s12-a': ('futbol-7','primera-divisio-alevi-s12'),
  'alevin-s12-b': ('futbol-7','segona-divisio-alevi-s12'),
  'alevin-s12-c': ('futbol-7','segona-divisio-alevi-s12'),
  'alevin-s12-d': ('futbol-7','tercera-divisio-alevi-s12'),
  'alevin-s11-a': ('futbol-7','primera-divisio-alevi-s11'),
  'alevin-s11-b': ('futbol-7','segona-divisio-alevi-s11'),
  'benjamin-s10-a': ('futbol-7','primera-divisio-benjami-s10'),
  'benjamin-s10-b': ('futbol-7','segona-divisio-benjami-s10'),
  'benjamin-s10-c': ('futbol-7','tercera-divisio-benjami-s10'),
  'benjamin-s9-a': ('futbol-7','preferent-benjami-s9'),
  'benjamin-s9-b': ('futbol-7','segona-divisio-benjami-s9'),
  'prebenjamin-s8-a': ('futbol-7','primera-divisio-prebenjami-s8'),
  'prebenjamin-s8-b': ('futbol-7','primera-divisio-prebenjami-s8'),
  'prebenjamin-s7-a': ('futbol-7','primera-divisio-prebenjami-s7'),
}
# Los grupos femeninos varían por modalidad según cada competición.
# No se inventa disciplina/slug: permanecen sin mapear hasta confirmar su ruta FCF.

def clean(s):
    return ' '.join(str(s or '').replace('\xa0',' ').split())

def simplify(s):
    s=unicodedata.normalize('NFD',clean(s)).lower()
    return ''.join(x for x in s if unicodedata.category(x)!='Mn')

def valid_official_url(raw):
    try:
        u=urlparse(raw)
        return u.scheme=='https' and u.netloc in ('fcf.cat','www.fcf.cat')
    except Exception:
        return False

def season_number(s):
    if not s:return None
    m=re.fullmatch(r'(20\d{2})[/-](20)?(\d{2})',clean(s))
    if not m:return None
    a=int(m[1]);b=int((m[2] or '20')+m[3])
    return a if a+1==b else None

def short_season(y):return f'{str(y)[-2:]}{str(y+1)[-2:]}'
def display_season(y):return f'{y}/{str(y+1)[-2:]}'

def season_of(s):
    m=SEASON_RE.search(clean(s))
    return int(m[1]) if m and int(m[1])+1 == int((m[2] or '20')+m[3]) else None

def html_is_season(html, year):
    # Confirmación explícita, nunca deducirla de la URL por sí sola.
    soup=BeautifulSoup(html,'html.parser')
    for elem in soup(['script','style','nav','footer']):elem.decompose()
    body=clean(soup.get_text(' ',strip=True)[:45000])
    return season_of(body)==year or (re.search(fr'\bTEMPORADA\s+{year}\s*[-/]\s*{year+1}\b',body,re.I) is not None)

def readable_date(s):
    s=clean(s)
    m=DATE_RE.search(s)
    if m:d,mo,y=map(int,m.groups())
    else:
        months={'enero':1,'gener':1,'febrero':2,'febrer':2,'marzo':3,'marc':3,
         'abril':4,'maig':5,'mayo':5,'juny':6,'junio':6,'juliol':7,'julio':7,
         'agost':8,'agosto':8,'septiembre':9,'setembre':9,'octubre':10,'noviembre':11,
         'novembre':11,'diciembre':12,'desembre':12}
        z=re.search(r'\b(\d{1,2})\s+de\s+([A-Za-zÀ-ÿ]+)\s+de\s+(20\d{2})\b',s,re.I)
        if not z:return None
        mo=months.get(simplify(z[2]))
        if not mo:return None
        d,y=int(z[1]),int(z[3])
    try:return date(y,mo,d).isoformat()
    except ValueError:return None

def compact_match_text(node):
    return clean(node.get_text(' ',strip=True))

def page_context_matches(html, team, year):
    if not html_is_season(html,year):return False
    soup=BeautifulSoup(html,'html.parser')
    full=clean(soup.get_text(' ',strip=True))
    start=SEASON_RE.search(full)
    if not start:return False
    head=full[start.start():start.start()+1400]
    group=str(team['group'])
    return bool(re.search(fr'\bGRUP(?:O)?\s*{re.escape(group)}\b',head,re.I) and
                simplify(team['division']).split()[0] in simplify(head))

def acta_from_html(html, url, expected_year=None, team=None):
    """Extrae únicamente del encabezado, no confunde goles del cuerpo con el resultado."""
    if not valid_official_url(url):return None
    soup=BeautifulSoup(html,'html.parser')
    for x in soup(['script','style']):x.decompose()
    lines=[clean(s) for s in soup.stripped_strings if clean(s)]
    text=' '.join(lines[:180])
    year=season_of(text)
    if not year or (expected_year is not None and expected_year!=year):return None
    ctx=COMP_RE.search(text)
    if team and (not ctx or str(team['group'])!=ctx[2] or not matches_division(ctx[1],team)):return None
    dt=readable_date(' '.join(x for x in lines[:130] if re.search(r'(?:data|fecha)\s*:',x,re.I)))
    if not dt:return None
    for i,line in enumerate(lines[:110]):
        if not re.fullmatch(r'ACTA\s+(?:TANCADA|CERRADA)',line,re.I):continue
        if i<1 or i+2>=len(lines):continue
        home,score,away=lines[i-1],lines[i+1],lines[i+2]
        m=re.fullmatch(r'(\d{1,2})\s*[-–:]\s*(\d{1,2})',score)
        if not (m and CLUB_RE.search(home+' '+away) and home!=away):continue
        return {'home':home,'away':away,'score':f'{m[1]}-{m[2]}','date':dt,'status':'final','url':url,'season':display_season(year)}
    return None

def matches_division(official, team):
    """Verificación prudente: categoría/edad/nivel, nunca solo el nombre del club."""
    a=simplify(official); b=simplify(team['division'])
    categories=('primera catalana','quarta catalana','juvenil','cadet','infantil','alevi','benjami','prebenjami','femeni')
    def level(s):
        for term in ('quarta','tercera','segona','segunda','primera','preferent'):
            if re.search(fr'\b{term}\b',s):return {'segunda':'segona'}.get(term,term)
        return ''
    if level(a) and level(b) and level(a)!=level(b):return False
    families=('prebenjami','benjami','alevi','infantil','cadet','juvenil','catalana')
    if next((f for f in families if f in a),None)!=next((f for f in families if f in b),None):return False
    sa=re.search(r'\bs(?:7|8|9|10|11|12|13|14|15|16)\b',a)
    sb=re.search(r'\bs(?:7|8|9|10|11|12|13|14|15|16)\b',b)
    return (sa.group(0) if sa else '')==(sb.group(0) if sb else '')

def candidate_score_cards(html, base_url):
    """Busca una tarjeta de 2 clubes y un marcador 'ACTA TANCADA' con vínculo a acta."""
    soup=BeautifulSoup(html,'html.parser')
    found={}
    for el in soup.find_all(string=re.compile(r'ACTA\s*TANCADA|ACTA\s*CERRADA',re.I)):
        node=el.parent
        for _ in range(6):
            if not isinstance(node,Tag):break
            txt=compact_match_text(node)
            if len(txt)>750:break
            if CLUB_RE.search(txt) and re.search(r'ACTA\s*(?:TANCADA|CERRADA)',txt,re.I):
                m=re.search(r'ACTA\s*(?:TANCADA|CERRADA)\s*(\d{1,2})\s*[-–:]\s*(\d{1,2})',txt,re.I)
                if m:
                    link=node.find('a',href=re.compile(r'/acta/|/competicio/acta/',re.I))
                    if not link:
                        # El marcador puede ser el mismo enlace.
                        link=el.parent.find_parent('a',href=True) if isinstance(el.parent,Tag) else None
                    if link:
                        url=urljoin(base_url,link.get('href',''))
                        if valid_official_url(url):found[url]=f'{m[1]}-{m[2]}'
                    break
            node=node.parent
    return found

def extract_standings(html):
    """Solo acepta una tabla con 2+ clubes, encabezados y puntos numéricos."""
    soup=BeautifulSoup(html,'html.parser')
    for table in soup.find_all('table'):
        rows=table.find_all('tr')
        if len(rows)<4:continue
        header=[simplify(x.get_text(' ',strip=True)) for x in rows[0].find_all(['th','td'])]
        if not any(re.fullmatch(r'(pts?|punts|puntos)',h) for h in header):continue
        points_col=next((i for i,h in enumerate(header) if re.fullmatch(r'(pts?|punts|puntos)',h)),None)
        played_col=next((i for i,h in enumerate(header) if h in ('pj','j','p','partits','jugats','jugados')),None)
        team_col=next((i for i,h in enumerate(header) if h in ('equip','equipo','club')),1)
        out=[]
        for row in rows[1:]:
            cells=[clean(x.get_text(' ',strip=True)) for x in row.find_all(['td','th'],recursive=False)]
            if len(cells)<=max(points_col,team_col):continue
            try:position=int(re.match(r'^\s*(\d{1,2})\b',cells[0]).group(1))
            except (AttributeError,ValueError):continue
            if not (1<=position<=32):continue
            try:pts=int(cells[points_col])
            except ValueError:continue
            team=cells[team_col]
            if not team or not re.search('[a-zÀ-ÿ]',team,re.I):continue
            try:played=int(cells[played_col]) if played_col is not None else None
            except (ValueError,IndexError):played=None
            out.append({'position':position,'team':team[:125],'played':played,'points':pts})
        if len(out)>=3 and any(CLUB_RE.search(x['team']) for x in out) and len(set(x['position'] for x in out))==len(out):return out
    return []

def candidate_fixture_cards(html,base_url,year):
    """Partidos con fecha+ambos equipos en una fila. Nunca usa fechas de navegación."""
    soup=BeautifulSoup(html,'html.parser'); output=[]; seen=set()
    for s in soup.find_all(string=CLUB_RE):
        if len(clean(str(s)))>150:continue
        node=s.parent
        for depth in range(5):
            if not isinstance(node,Tag):break
            txt=compact_match_text(node)
            if len(txt)>700:break
            dt=readable_date(txt)
            if dt and int(dt[:4]) in (year,year+1) and not re.search(r'ACTA\s*TANCADA',txt,re.I):
                chunks=[clean(x) for x in node.stripped_strings if clean(x)]
                names=[x for x in chunks if re.search(r'\b(?:F\.C\.|C\.F\.|C\.E\.|U\.E\.|FC\s|CF\s|,\s*C\.)',x,re.I)]
                # Los rivales se identifican con dos nombres distintos en un único bloque.
                names=list(dict.fromkeys(x for x in names if x!='' and len(x)<115))
                if len(names)==2 and any(CLUB_RE.search(x) for x in names):
                    tim=re.search(r'\b([01]?\d|2[0-3]):([0-5]\d)\b',txt)
                    link=node.find('a',href=re.compile(r'/acta/|/competicio/acta/',re.I))
                    url=urljoin(base_url,link['href']) if link else base_url
                    if valid_official_url(url):
                        key=(dt,names[0],names[1]);
                        if key not in seen:
                            seen.add(key); output.append({'date':dt,'home':names[0],'away':names[1], 'time':tim.group(0) if tim else '', 'url':url})
                    break
            node=node.parent
    return output

class OfficialClient:
    def __init__(self,timeout=15):
        self.session=requests.Session()
        self.session.headers.update({'User-Agent':'LA-COOPE-PublicCalendar/1.0 (+https://github.com/; non-commercial)','Accept':'text/html,application/xhtml+xml','Accept-Language':'ca,es;q=.8'})
        self.timeout=timeout;self.cache={};self.errors=[];self.rendered_count=0
    def get(self,url):
        if not valid_official_url(url):raise ValueError('URL externa bloqueada')
        if url in self.cache:return self.cache[url]
        try:
            r=self.session.get(url,timeout=self.timeout,allow_redirects=True)
            if not valid_official_url(r.url):raise RuntimeError('Redirección a un sitio externo')
            r.raise_for_status()
            if not ('html' in r.headers.get('Content-Type','').lower() or r.text.lstrip().startswith('<')):raise RuntimeError('Respuesta no HTML')
            if len(r.content)>2_500_000:raise RuntimeError('Página demasiado grande')
            self.cache[url]=r.text;return r.text
        except (requests.RequestException,RuntimeError,ValueError) as ex:
            self.errors.append(f'{url}: {str(ex)[:120]}')
            return None

    def render(self,url):
        """Segundo intento con navegador real si la FCF entrega tablas vacías."""
        if self.rendered_count>=5 or not valid_official_url(url):return None
        self.rendered_count+=1
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
                page=browser.new_page(locale='ca-ES',timezone_id='Europe/Madrid')
                page.goto(url,wait_until='domcontentloaded',timeout=int(self.timeout*1000))
                page.wait_for_timeout(2200)
                html=page.content()
                browser.close()
                if len(html)>2_500_000:raise RuntimeError('HTML renderizado demasiado grande')
                self.cache[url]=html
                return html
        except Exception as ex:
            self.errors.append(f'Navegador {url}: {str(ex)[:100]}')
            return None

def team_urls(team,year):
    disc,slug=(team.get('fcfDiscipline'),team.get('fcfSlug')) if team.get('fcfDiscipline') and team.get('fcfSlug') else DIV_SLUGS[team['id']]
    p=f'{short_season(year)}/{disc}/{slug}/grup-{team["group"]}'
    return {section:f'{ORIGIN}/{section}/{p}' for section in ('resultats','calendari','classificacio')}

def collect(client, team, year, old=None):
    if team['id'] not in DIV_SLUGS:return None
    urls=team_urls(team,year)
    primary=client.get(urls['resultats'])
    if not primary or not page_context_matches(primary,team,year):
        primary=client.render(urls['resultats'])
    if not primary or not page_context_matches(primary,team,year):return None
    if not CLUB_RE.search(BeautifulSoup(primary,'html.parser').get_text(' ',strip=True)):
        # Una categoría/grupo sin Ciudad Cooperativa NO puede asociarse al equipo.
        return None
    result_pages=[(urls['resultats'],primary)]
    # La portada suele estar en la jornada vigente. Buscamos 3 anteriores para
    # evitar huecos en partidos aplazados, sin intentar extraer fechas del orden HTML.
    m=re.search(r'\bJornada\s*(\d{1,2})\b',BeautifulSoup(primary,'html.parser').get_text(' ',strip=True)[:3000],re.I)
    future_pages=[]
    if m:
        j=int(m[1]);
        for n in range(max(1,j-3),j):
            u=urls['resultats']+f'/jornada-{n}'
            h=client.get(u)
            if h and page_context_matches(h,team,year):result_pages.append((u,h))
        for n in range(j+1,min(j+3,31)):
            u=urls['resultats']+f'/jornada-{n}'
            h=client.get(u)
            if h and page_context_matches(h,team,year):future_pages.append((u,h))
    cards={}
    for u,h in result_pages:cards.update(candidate_score_cards(h,u))
    results=[]
    for acta_url,expected_score in list(cards.items())[:8]:
        acta=client.get(acta_url)
        game=acta_from_html(acta or '',acta_url,year,team) if acta else None
        if game and game['score']==expected_score:results.append({k:v for k,v in game.items() if k!='season'})
    # Conserva actas validadas previamente de la MISMA temporada cuando la web
    # actual muestre pocas jornadas (y siempre ordena por fecha real).
    for previous in (old or {}).get('results',[]):
        if previous.get('date','')[:4] not in (str(year),str(year+1)):continue
        if previous.get('status')!='final' or not valid_official_url(previous.get('url','')):continue
        if not any((g['date'],g['home'],g['away'])==(previous['date'],previous['home'],previous['away']) for g in results):
            results.append(previous)
    results=sorted(results,key=lambda g:g['date'],reverse=True)[:12]
    fixture_page=client.get(urls['calendari'])
    fixtures=[]
    if fixture_page and page_context_matches(fixture_page,team,year):
        fixtures=candidate_fixture_cards(fixture_page,urls['calendari'],year)
    if not fixtures:
        fixture_page=client.render(urls['calendari'])
        if fixture_page and page_context_matches(fixture_page,team,year):
            fixtures=candidate_fixture_cards(fixture_page,urls['calendari'],year)
    for u,h in future_pages:
        fixtures.extend(candidate_fixture_cards(h,u,year))
    fixtures=list({(g['date'],g['home'],g['away']):g for g in fixtures}.values())
    # Una fecha de calendario no sustituye a un acta cerrada.
    ended={(g['date'],simplify(g['home']),simplify(g['away'])) for g in results}
    fixtures=[g for g in fixtures if (g['date'],simplify(g['home']),simplify(g['away'])) not in ended]
    fixtures=sorted(fixtures,key=lambda g:g['date'])[:50]
    standings=[]
    table_page=client.get(urls['classificacio'])
    if table_page and page_context_matches(table_page,team,year):standings=extract_standings(table_page)
    if not standings:
        table_page=client.render(urls['classificacio'])
        if table_page and page_context_matches(table_page,team,year):standings=extract_standings(table_page)
    if not standings and old:standings=old.get('standings',[])
    me=next((x for x in standings if CLUB_RE.search(x['team'])),{})
    if not (results or fixtures or standings):return None
    return {'results':results,'fixtures':fixtures,'standings':standings,'position':me.get('position'),
      'points':me.get('points'),'competitionUrl':urls['resultats'],'source':urls['resultats'],
      'updatedAt':datetime.now(timezone.utc).isoformat(timespec='seconds')}

def candidate_primary_competitions(team):
    """Solo al abrirse curso nuevo. Buscar ascenso/descenso entre ligas vecinas."""
    return [team] + [dict(team,division=division,group=str(g),fcfDiscipline='futbol-11',fcfSlug=slug)
      for division,slug,limit in [('Lliga Elit','lliga-elit',1),
                                   ('Primera Catalana','primera-catalana',3),
                                   ('Segona Catalana','segona-catalana',6)]
      for g in range(1,limit+1) if not (division==team['division'] and str(g)==str(team['group']))]

def update(feed,teams, client, when, only_first=False):
    previous=season_number(feed.get('season'))
    current=when.year if when.month>=7 else when.year-1
    primary=teams[0]
    # Solo investigar el próximo curso a partir de junio. Nunca elegirlo por fecha;
    # se valida temporada en HTML, grupo y presencia del primer equipo.
    next_year=previous+1 if previous else current
    new_primary=None
    proposed_primary=None
    if previous is None or when.year>next_year or (when.year==next_year and when.month>=6):
        for target in candidate_primary_competitions(primary):
            url=team_urls(target,next_year)['resultats']
            page=client.get(url)
            if not page or not page_context_matches(page,target,next_year):continue
            txt=BeautifulSoup(page,'html.parser').get_text(' ',strip=True)
            if not CLUB_RE.search(txt):continue
            # Se intenta la coincidencia con el primer equipo; nunca confundir con B.
            if not re.search(r'CIUDAD\s+COOPERATIVA\s*,?\s*C\.?F\.?\s*["“]?A\b',txt,re.I):continue
            fresh=collect(client,target,next_year)
            if fresh:
                proposed_primary=target;new_primary=fresh;break
    confirmed_year=next_year if new_primary else previous
    if confirmed_year is None:
        return None
    new_season=display_season(confirmed_year)
    changed=previous!=confirmed_year
    prior_snap={} if changed else feed.get('snapshots',{})
    pending=copy.deepcopy(teams)
    if proposed_primary:pending[0]=proposed_primary
    snapshots={}
    n_fresh=0
    for t in pending[:1] if only_first else pending:
        before=prior_snap.get(t['id'])
        if t['id']==primary['id'] and new_primary is not None:data=new_primary
        else:data=collect(client,t,confirmed_year,before)
        if data:
            snapshots[t['id']]=data;n_fresh+=1
        elif before:snapshots[t['id']]=before
    if changed and new_primary is None:return None
    feed['season']=new_season
    if changed:
        feed['officialEvidence']=[team_urls(pending[0],confirmed_year)['resultats']]
        feed['teams']=pending
    feed['source']='fcf.cat';feed['confirmed']=True
    feed['snapshots']=snapshots
    # Una descarga fallida nunca se registra como actualización nueva.
    if n_fresh:feed['updatedAt']=datetime.now(timezone.utc).isoformat(timespec='seconds')
    return feed

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--solo-amateur',action='store_true')
    p.add_argument('--timeout',type=float,default=18)
    args=p.parse_args()
    feed=json.loads(FEED.read_text(encoding='utf8'))
    teams=feed.get('teams') or json.loads(TEAMS.read_text(encoding='utf8'))
    client=OfficialClient(args.timeout)
    updated=update(feed,teams,client,datetime.now(timezone.utc),args.solo_amateur)
    diagnostics={'checkedAt':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                 'fcfReachable':bool(client.cache),'pagesRead':len(client.cache),'browserRenders':client.rendered_count,
                 'teamsWithData':len((updated or feed).get('snapshots',{})),
                 'verifiedSeason':(updated or feed).get('season'),
                 'errors':client.errors[:12],
                 'note':'Si fcfReachable es falso, comprobar conectividad, rutas oficiales y permisos del sitio. No se inventan resultados.'}
    DIAG.write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    if updated is None:print('Sin temporada confirmada; feed intacto')
    elif updated.get('snapshots') and client.cache:
        FEED.write_text(json.dumps(updated,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        print('Temporada:',updated['season'],'| equipos con datos:',len(updated['snapshots']))
    else:print('FCF no ha proporcionado datos verificables; feed intacto')
    for error in client.errors[:3]:print('ADVERTENCIA',error)

if __name__=='__main__':main()

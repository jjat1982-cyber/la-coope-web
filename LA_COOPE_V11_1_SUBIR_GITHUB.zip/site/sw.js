// El HTML se actualiza por red; feed.json nunca se cachea en el Service Worker.
const CACHE='la-coope-web-v11-1';
const SHELL=['./','./index.html','./styles.css','./season.js','./app.js','./teams.json','./escudo-transparente.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)));
 self.skipWaiting();
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
 self.clients.claim();
});
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);
 if(event.request.method!=='GET'||u.origin!==self.location.origin)return;
 if(/\/feed\.json$|\/diagnostico\.json$/.test(u.pathname))return;
 event.respondWith(fetch(event.request).then(r=>{
  if(r.ok)caches.open(CACHE).then(c=>c.put(event.request,r.clone()));
  return r;
 }).catch(()=>caches.match(event.request)));
});

'use strict';
const CLUB='https://www.fcf.cat/ca/clubs';
const ACT_EXAMPLE='https://www.fcf.cat/ca/competicio/acta/4208561';
const COMP='https://www.fcf.cat/ca/competicio';
const DEFAULT_COMP='https://www.fcf.cat/ca/competicio';
const COMP_LIST='https://www.fcf.cat/ca/competicio-futbol';
const PRIMARY_FCF_SLUG='futbol-11/primera-catalana/grup-3';
const KEY_FAV='lacoope-v8-favorite';
const KEY_VIEW='lacoope-v8-selected';
const MAIN_TEAM='amateur-a';
const DATA_KEY='lacoope-web-snapshot-v1';
const OLD_DATA_KEY='lacoope-web-snapshot-v1';
let currentSeason=null,feedCheckedAt=null;let officialSnapshots={};let sourceStatus='Consultando datos oficiales al abrir Inicio…';
let teams=[],knownGames=[];
let tab='inicio', selected=MAIN_TEAM, favorite='',category='Todos', search='',filterGames='todos';
let installPrompt=null,toastTimer=null,liveWatching=false;
const safe=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const byId=id=>teams.find(t=>t.id===id)||teams[0];
const save=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const load=k=>{try{return localStorage.getItem(k)||''}catch(e){return''}};
const allCount=()=>teams.length;
const teamGames=id=>knownGames.filter(g=>g.team===id).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
const dateFmt=d=>{if(!d)return 'Fecha pendiente';const [y,m,day]=d.split('-');return `${day}/${m}/${y}`};
const iconOut=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9"/><path d="M20 13v6H5V5h6"/></svg>`;
function official(url=CLUB){
 try{const u=new URL(url);if(u.protocol!=='https:'||!['www.fcf.cat','fcf.cat'].includes(u.hostname))throw Error('Origen no oficial');
 if(window.LACOOPE&&typeof window.LACOOPE.openOfficial==='function'){window.LACOOPE.openOfficial(u.href);return}
 window.open(u.href,'_blank','noopener,noreferrer');
 }catch(e){toast('Solo enlaces oficiales fcf.cat')}
}
async function triggerSync(){
 sourceStatus='Comprobando datos y temporada publicados…';render();
 try{
  const r=await fetch('./feed.json?check='+Date.now(),{cache:'no-store'});
  if(!r.ok)throw Error('El archivo de datos no respondió');
  const feed=await r.json();
  const s=CoopeSeason.acceptFeed(feed,currentSeason?.label);
  if(!s)throw Error('No se ha confirmado una temporada válida en la fuente oficial');
  const was=currentSeason?.label;currentSeason=s;
  // No mezclar fichas y resultados de temporadas diferentes.
  if(was&&was!==s.label){officialSnapshots={};knownGames=[];save(DATA_KEY,'{}')}
  const raw=feed.snapshots||{};
  let accepted=0;
  for(const [id,info] of Object.entries(raw)){
   if(!teams.some(t=>t.id===id)||!info||typeof info!=='object')continue;
   // Solo resultados registrados con fecha válida y procedencia FCF comprobable.
   const validUrl=u=>{try{const x=new URL(u);return x.protocol==='https:'&&['fcf.cat','www.fcf.cat'].includes(x.hostname)}catch(e){return false}};
   const validGame=g=>g&&/^20\d{2}-\d{2}-\d{2}$/.test(g.date||'')&&g.home&&g.away&&validUrl(g.url||info.source);
   const results=(info.results||[]).filter(g=>validGame(g)&&g.status==='final'&&/^\d{1,2}\s*[-:]\s*\d{1,2}$/.test(g.score||''));
   const fixtures=(info.fixtures||[]).filter(g=>validGame(g));
   const standings=Array.isArray(info.standings)?info.standings.filter(x=>Number.isInteger(x.position)&&x.team&&Number.isInteger(x.points)):[];
   if(results.length||fixtures.length||standings.length){
    officialSnapshots[id]={results,fixtures,standings,position:Number.isInteger(info.position)?info.position:null,points:Number.isInteger(info.points)?info.points:null,updatedAt:info.updatedAt||feed.updatedAt,competitionUrl:validUrl(info.competitionUrl)?info.competitionUrl:undefined,source:validUrl(info.source)?info.source:undefined};accepted++;
   }
  }
  // Team information may change with relegation/promotion: only accept a catalog supplied and verified by the collector.
  if(Array.isArray(feed.teams)&&feed.teams.length&&feed.teams.some(t=>t.id==='amateur-a')&&feed.teams.every(t=>t.id&&t.name&&t.division&&t.group)){
    teams=feed.teams;
  }
  save(DATA_KEY,JSON.stringify({season:s.label,snapshots:officialSnapshots}));feedCheckedAt=new Date().toISOString();
  sourceStatus=accepted?`Datos publicados de ${accepted} equipos · última lectura FCF: ${feed.updatedAt?new Date(feed.updatedAt).toLocaleString('es-ES'):'sin fecha'}`:`Temporada ${s.label} confirmada, sin marcadores nuevos.`;
  if(!accepted){
    try{
      const d=await fetch('./diagnostico.json?check='+Date.now(),{cache:'no-store'}).then(r=>r.ok?r.json():null);
      if(d?.checkedAt && d.fcfReachable===false)sourceStatus='La lectura automática no consiguió conectar con la FCF. Consulta el diagnóstico de GitHub.';
      else if(d?.checkedAt && d.fcfReachable===true)sourceStatus='FCF consultada, pero todavía sin partidos verificables. Revisa el diagnóstico de GitHub.';
    }catch(e){}
  }
 }catch(err){sourceStatus='No se pudo actualizar: '+err.message+'. Conservamos los últimos datos válidos.'}
 render();
}
function teamFCFUrl(id){
 const u=officialSnapshots[id]?.competitionUrl;
 if(id===MAIN_TEAM&&currentSeason?.short&&!u)return `https://www.fcf.cat/resultats/${currentSeason.short}/${PRIMARY_FCF_SLUG}`;
 try{const x=new URL(u);if(x.protocol==='https:'&&['www.fcf.cat','fcf.cat'].includes(x.hostname))return u}catch(e){}
 return DEFAULT_COMP;
}
function officialSectionUrl(id,section){
 return CoopeSeason.officialSection(teamFCFUrl(id),section)||teamFCFUrl(id);
}
function mostRecent(id){let xs=(officialSnapshots[id]?.results||[]).filter(x=>x.status==='final'&&x.date);xs.sort((a,b)=>b.date.localeCompare(a.date));return xs[0]||null}
function localToday(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Madrid',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function nextFixture(id){let now=localToday();let xs=(officialSnapshots[id]?.fixtures||[]).filter(x=>x.date&&x.date>=now);xs.sort((a,b)=>a.date.localeCompare(b.date));return xs[0]||null}
function metricLast(id){const r=mostRecent(id);return r?`${safe(r.home)} ${safe(r.score)} ${safe(r.away)}<small>${dateFmt(r.date)} · Último localizado; puede haber partidos más recientes · FCF</small>`:'Pendiente de lectura oficial'}
function metricNext(id){const r=nextFixture(id);return r?`${safe(r.home)} – ${safe(r.away)}<small>${dateFmt(r.date)} ${safe(r.time||'')} · FCF</small>`:'Pendiente de lectura oficial'}
function snapshotAsOf(id){
 const at=officialSnapshots[id]?.updatedAt;
 if(!at||!Number.isFinite(Date.parse(at)))return 'Sin consulta oficial registrada';
 return 'Datos consultados: '+new Date(at).toLocaleString('es-ES',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
}
function metricPosition(id){const snapshot=officialSnapshots[id]||{};const p=snapshot.position;return Number.isInteger(p)&&p>0?`${p}º${Number.isInteger(snapshot.points)?` · ${snapshot.points} pts`:''} (FCF)`:'Pendiente de lectura'}
function normal(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
function identifyTeam(payload){
 // Solo asociar una ficha cuando coincidan categoría, subedad, división y grupo.
 // Una asignación errónea es peor que mostrar "pendiente de lectura".
 const cat=normal(payload.category||'');
 const group=String(payload.group||'').match(/^\s*(\d{1,2})\s*$/)?.[1];
 if(!cat||!group)return null;
 const age=cat.match(/\bs(?:7|8|9|10|11|12|13|14|15|16)\b/)?.[0]||'';
 const level=cat.match(/\b(primera|segona|segunda|tercera|quarta|cuarta|preferent)\b/)?.[1]||'';
 const standard=s=>s==='segunda'?'segona':s==='cuarta'?'quarta':s;
 const categoryOf=s=>{
  if(/prebenjami/.test(s))return 'prebenjamin';
  if(/benjami/.test(s))return 'benjamin';
  if(/alevi/.test(s))return 'alevin';
  if(/infantil/.test(s))return 'infantil';
  if(/cadet/.test(s))return 'cadete';
  if(/juvenil/.test(s))return 'juvenil';
  if(/catalana|amateur/.test(s))return 'amateur';
  return '';
 };
 const candidates=teams.filter(t=>{
  const div=normal(t.division), cName=normal(t.category);
  if(String(t.group)!==group)return false;
  const family=categoryOf(div), officialFamily=categoryOf(cat);
  if(!family||!officialFamily||family!==officialFamily)return false;
  const teamAge=div.match(/\bs(?:7|8|9|10|11|12|13|14|15|16)\b/)?.[0]||'';
  if(teamAge!==age)return false;
  const divisionLevel=div.match(/\b(primera|segona|segunda|tercera|quarta|cuarta|preferent)\b/)?.[1]||'';
  if(level&&divisionLevel&&standard(level)!==standard(divisionLevel))return false;
  const teamFemale=/femenin|femeni/.test(div+' '+cName);
  const officialFemale=/femenin|femeni/.test(cat);
  if(teamFemale!==officialFemale)return false;
  return true;
 });
 return candidates.length===1?candidates[0].id:null;
}

function toast(msg){const n=document.getElementById('toast');n.textContent=msg;n.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.classList.remove('show'),3400)}
function choose(id){if(!teams.some(t=>t.id===id))return;favorite=id;save(KEY_FAV,id);render();toast('Favorito guardado en este dispositivo');

}
function pick(id){
 if(!teams.some(t=>t.id===id))return;
 const changed=selected!==id;
 selected=id;save(KEY_VIEW,id);render();
 if(changed&&liveWatching){
   liveWatching=false;

 }
 if(changed&&['partidos','resultados','clasificacion'].includes(tab))notifyScreenOpened();
}
function changeLiveWatching(){triggerSync();}
function notifyScreenOpened(){
 if(!feedCheckedAt || Date.now()-Date.parse(feedCheckedAt)>300000)triggerSync();
}

function btnFCF(label='Abrir ficha oficial',url=CLUB,cls='btn'){return `<button class="${cls}" type="button" data-open="${safe(url)}">${safe(label)} ${iconOut}</button>`}
function teamSelect(){return `<label class="eyebrow" for="teamselect">Equipo</label><select id="teamselect" aria-label="Equipo">${teams.map(t=>`<option value="${safe(t.id)}" ${selected===t.id?'selected':''}>${safe(t.name)}</option>`).join('')}</select>`}
function summaryMetric(title,id){let v=title==='ÚLTIMO RESULTADO'?metricLast(id):title==='PRÓXIMO PARTIDO'?metricNext(id):metricPosition(id);return `<div class="metric ${title==='POSICIÓN'?'wide':''}"><div><small>${title}</small><strong>${v}</strong></div></div>`}
function archiveLine(g){return `<div class="score-item"><div><small>${safe(g.date?dateFmt(g.date):g.dateLabel)} · ${safe(byId(g.team).name)}</small><strong>${safe(g.home)}<br>${safe(g.away)}</strong><a class="muted-link" href="${safe(g.url)}" target="_blank" rel="noopener noreferrer">${safe(g.sourceType)} ↗</a></div><span class="score-box mono">${g.homeScore}–${g.awayScore}</span></div>`}
function teamHero(t){return `<div class="card hero-card"><div class="strip"></div><div class="hero-head"><span class="hero-label">EL PRIMER EQUIPO</span><span class="tag dark">★ REFERENTE</span></div><h2 class="hero-title">${safe(t.name)}</h2><p class="hero-sub">${safe(t.division)} · Grupo ${safe(t.group)}</p><div class="metric-grid">${summaryMetric('ÚLTIMO RESULTADO',t.id)}${summaryMetric('PRÓXIMO PARTIDO',t.id)}${summaryMetric('POSICIÓN',t.id)}</div><div class="hero-bottom">${btnFCF('Ver calendario',officialSectionUrl(t.id,'calendari'))}${btnFCF('Clasificación',officialSectionUrl(t.id,'classificacio'),'btn outline')}</div><div class="spotlight-note">${safe(snapshotAsOf(t.id))}</div><div class="spotlight-note">Los resultados y la posición se muestran solo cuando la FCF devuelve datos verificables.</div></div>`}
function favoriteCard(){if(!favorite||!teams.some(t=>t.id===favorite))return `<div class="card"><div class="favorite-choose"><div class="section-label">☆ MI EQUIPO FAVORITO</div><h3 style="font-size:19px;letter-spacing:-.35px">¿Qué equipo quieres seguir?</h3><p class="faint" style="font-size:12px">Selecciona cualquier categoría, desde Amateur hasta Prebenjamín.</p><button class="btn" data-tab="equipos">Elegir equipo ☆</button></div></div>`;
const t=byId(favorite);return `<div class="card"><div class="favorite-header"><div><div class="section-label">★ MI EQUIPO FAVORITO</div><strong>${safe(t.name)}</strong><small>${safe(t.division)} · Grupo ${safe(t.group)}</small></div><button class="star" aria-label="Cambiar favorito" title="Cambiar favorito" data-tab="equipos">★</button></div><div class="favorite-body"><div class="thinmetrics"><div class="thinmetric"><small>ÚLTIMO RESULTADO</small><strong>${metricLast(t.id)}</strong></div><div class="thinmetric"><small>PRÓXIMO PARTIDO</small><strong>${metricNext(t.id)}</strong></div></div><div class="thinmetric" style="min-height:55px;margin-bottom:12px"><small>CLASIFICACIÓN</small><strong>${metricPosition(t.id)}</strong></div><div class="split">${btnFCF('Ver partidos',officialSectionUrl(t.id,'calendari'))}<button class="btn outline-dark" data-tab="equipos">Cambiar ★</button></div></div></div>`}
function renderHome(){return `<h1 class="page-title">LA COOPE</h1><p class="page-sub">Una vez de la Coope, siempre de la Coope.</p>${`<div class="notice"><b>Lectura FCF:</b> ${safe(sourceStatus)} <button class="btn" type="button" data-sync="yes" style="margin:9px 0 0">↻ Actualizar</button></div>`}${teamHero(byId(MAIN_TEAM))}${favoriteCard()}<div class="notice"><b>Actualización:</b> consultamos el archivo de datos online al abrir o volver a Inicio. La app consulta el JSON de GitHub; el lector automático debe verificar cada acta en la FCF antes de actualizarlo. No es un servicio de marcadores en directo.</div>${btnFCF('Portal de competiciones FCF',COMP,'btn full')}<footer>LA COOPE · Temporada ${safe(currentSeason?.label||"por confirmar")} · Club FCF 2899</footer>`}
function liveNow(id){
 const snapshot=officialSnapshots[id];
 if(!snapshot||!snapshot.updatedAt||Date.now()-new Date(snapshot.updatedAt).getTime()>5*60*1000)return [];
 const today=new Date();
 const localDay=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
 return (snapshot.live||[]).filter(m=>m.date===localDay && m.status==='live');
}
function renderPartidos(){let t=byId(selected),f=officialSnapshots[t.id]?.fixtures||[];
 const next=f.filter(x=>x.date>=localToday()).sort((a,b)=>(a.date+' '+(a.time||'')).localeCompare(b.date+' '+(b.time||'')));
 return `<h1 class="page-title">Calendario y directo</h1><p class="page-sub">Partidos detectados en páginas oficiales</p><div class="card" style="padding:15px">${teamSelect()}<p class="faint" style="font-size:11px;margin:9px 0 0">${safe(t.division)} · Grupo ${safe(t.group)}</p></div><div class="card">${next.length?next.slice(0,20).map(g=>`<div class="score-item"><div><small>${dateFmt(g.date)} · ${safe(g.time||'Hora pendiente')}</small><strong>${safe(g.home)} – ${safe(g.away)}</strong></div><a class="muted-link" href="${safe(g.url)}">FCF ↗</a></div>`).join(''):`<div class="table-empty"><span>▦</span><h3>Próximo encuentro no verificado</h3><p>La app aún no ha identificado un calendario completo para este grupo. Consulta el portal de competiciones de la FCF.</p>${btnFCF('Consultar calendario FCF',officialSectionUrl(t.id,'calendari'))}</div>`}</div><div class="callout"><strong>Marcador en directo</strong><p>Los datos se actualizan desde el archivo publicado por GitHub. No hay marcador en directo continuo verificado.</p>${liveNow(t.id).map(m=>`<div class="score-item"><strong>${safe(m.home)} ${safe(m.score)} ${safe(m.away)}</strong><small>EN DIRECTO · FCF</small></div>`).join('')||'<p>Sin marcador en directo verificado.</p>'}<button class="btn" data-live="yes">Actualizar datos publicados</button>${btnFCF('Abrir competición FCF',teamFCFUrl(t.id))}</div>`}
function latestResultCard(id,label){
 const t=byId(id),m=mostRecent(id);
 if(!t)return '';
 const header=`<div class="section-label">${safe(label)}</div><h3 style="margin:5px 0">${safe(t.name)}</h3><small>${safe(t.division)} · Grupo ${safe(t.group)}</small>`;
 if(!m)return `<div class="card" style="padding:17px">${header}<div class="table-empty"><h3>Resultado pendiente de lectura oficial</h3><p>No se ha recuperado todavía el último encuentro de este equipo en la FCF. No mostramos actas antiguas como resultados recientes.</p>${btnFCF('Consultar resultados FCF',officialSectionUrl(id,'resultats'))}</div></div>`;
 const daysAgo=Math.floor((Date.now()-new Date(m.date+'T12:00:00').getTime())/86400000);
 const old=daysAgo>18;
 return `<div class="card" style="padding:17px">${header}<div class="score-item" style="margin-top:12px"><div><small>${safe(dateFmt(m.date))} · ${old?'Último localizado; actualidad no verificada':'Último localizado en FCF'}</small><strong>${safe(m.home)}<br>${safe(m.away)}</strong></div><span class="score-box mono">${safe(m.score).replace('-', '–')}</span></div><div class="spotlight-note">${safe(snapshotAsOf(id))}</div>${old?'<div class="notice">Este marcador podría no corresponder a la última jornada. La app no ha podido confirmar uno más reciente.</div>':''}${btnFCF('Ver resultados oficiales',officialSectionUrl(id,'resultats'),'btn outline')}</div>`;
}
function renderResults(){
 const duplicated=favorite===MAIN_TEAM;
 const extra=favorite&&!duplicated&&teams.some(t=>t.id===favorite)
   ?latestResultCard(favorite,'★ EQUIPO FAVORITO')
   :`<div class="card" style="padding:18px"><div class="section-label">★ MI EQUIPO FAVORITO</div><p class="faint">${duplicated?'Has elegido Amateur A como favorito; ya aparece arriba.':'Elige tu equipo favorito para ver aquí su último resultado.'}</p><button class="btn" data-tab="equipos">Elegir favorito</button></div>`;
 return `<h1 class="page-title">Últimos resultados</h1><p class="page-sub">Un encuentro por equipo: Amateur A y favorito. Datos leídos desde fcf.cat.</p>${latestResultCard(MAIN_TEAM,'PRIMER EQUIPO · AMATEUR A')}${extra}<div class="notice">La última jornada se determina por fecha, nunca por el orden de aparición en la página. Si la FCF no proporciona datos verificables, no se inventará un marcador.</div>`;
}
function renderClassification(){let t=byId(selected),snap=officialSnapshots[t.id]||{},rows=Array.isArray(snap.standings)?snap.standings:[];
 return `<h1 class="page-title">Clasificación</h1><p class="page-sub">Solo tablas reconocidas desde el portal oficial</p><div class="card" style="padding:15px">${teamSelect()}<p class="faint" style="font-size:11px;margin:9px 0 0">${safe(t.division)} · Grupo ${safe(t.group)}</p></div><div class="card"><table class="stand-table"><thead><tr><th>POS.</th><th>EQUIPO</th><th>PJ</th><th>PTS</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${safe(r.position)}</td><td>${safe(r.team)}</td><td>${safe(r.played??'—')}</td><td>${safe(r.points??'—')}</td></tr>`).join('')}</tbody></table>${rows.length?'':`<div class="table-empty"><span>≡</span><h3>Tabla pendiente de lectura</h3><p>Solo se completará cuando podamos identificar con seguridad una clasificación de este grupo en la web federativa.</p>${btnFCF('Consultar clasificación FCF',officialSectionUrl(t.id,'classificacio'))}</div>`}</div><div class="notice">Las posiciones pueden cambiar al actualizarse las actas. La última tabla reconocida se conserva localmente con su fecha de consulta.</div>`}
const categories=['Todos','Amateur','Juvenil','Cadete','Infantil','Alevín','Benjamín','Prebenjamín','Femenino'];
function renderTeams(){let visible=teams.filter(t=>(category==='Todos'||t.category===category)&&(!search||(t.name+' '+t.division).toLocaleLowerCase('es').includes(search.toLocaleLowerCase('es'))));return `<h1 class="page-title">Los equipos</h1><p class="page-sub">${allCount()} equipos · Elige tu favorito con la estrella</p><div class="toolbar"><input id="teams-search" type="search" placeholder="Buscar equipo o categoría…" value="${safe(search)}" autocomplete="off" aria-label="Buscar equipos"></div><div class="pill-row">${categories.map(c=>`<button class="pill ${category===c?'selected':''}" data-category="${safe(c)}">${safe(c)}</button>`).join('')}</div><div class="card">${visible.length?visible.map((t,i)=>`<div class="team-row"><span class="team-number">${t.name.includes('Amateur')?'A':t.name.slice(0,1)}</span><div class="team-info"><strong>${safe(t.name)}</strong><small>${safe(t.division)} · Grupo ${safe(t.group)}</small></div><div class="team-actions"><button class="text-button" data-pick="${safe(t.id)}">Ver</button><button class="team-fav ${favorite===t.id?'on':''}" data-fav="${safe(t.id)}" aria-label="${favorite===t.id?'Favorito actual':'Marcar como favorito'} ${safe(t.name)}">${favorite===t.id?'★':'☆'}</button></div></div>`).join(''):`<div class="empty-state"><strong>No se encontraron equipos</strong>Prueba otra categoría.</div>`}</div><div class="callout"><strong>Club Ciutat Cooperativa</strong><p>La estructura de equipos corresponde al último inventario confirmado. Las divisiones y grupos deberán actualizarse al publicar la FCF los del nuevo curso.</p>${btnFCF('Consultar clubes en la FCF',CLUB)}</div>`}
function render(){const sb=document.querySelector('.season-bar>span:first-child');if(sb)sb.innerHTML='<span class="yellow-dot"></span> Temporada '+safe(currentSeason?.label||'por confirmar');const view=document.getElementById('view');view.innerHTML=({inicio:renderHome,partidos:renderPartidos,resultados:renderResults,clasificacion:renderClassification,equipos:renderTeams}[tab]||renderHome)();document.querySelectorAll('.nav-link').forEach(b=>{let active=b.dataset.tab===tab;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')})}
function navigate(t){
 if(!['inicio','partidos','resultados','clasificacion','equipos'].includes(t))return;
 const changed=t!==tab;
 if(t!=='partidos'&&liveWatching){liveWatching=false;
}
 tab=t;
 // No activar seguimiento de directos automáticamente solo por abrir Partidos.
 // El usuario puede iniciarlo con su botón; únicamente entonces habrá sondeo cada 2 min.
 render();window.scrollTo({top:0,behavior:'instant'});
 if(changed)notifyScreenOpened();if(t==='inicio')triggerSync();
}

document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el){const a=e.target.closest('a[href]');if(a&&/^https:\/\/www\.fcf\.cat\//.test(a.href)){e.preventDefault();official(a.href)}return}if(el.dataset.tab)navigate(el.dataset.tab);if(el.dataset.sync)triggerSync();if(el.dataset.live)changeLiveWatching();if(el.dataset.open)official(el.dataset.open);if(el.dataset.fav)choose(el.dataset.fav);if(el.dataset.pick){pick(el.dataset.pick);navigate('partidos')}if(el.dataset.category){category=el.dataset.category;render()}if(el.dataset.results){filterGames=el.dataset.results;render()}});
document.addEventListener('change',e=>{if(e.target.id==='teamselect')pick(e.target.value)});
document.addEventListener('input',e=>{if(e.target.id==='teams-search'){
 search=e.target.value;
 const cursor=e.target.selectionStart;
 render();
 const next=document.getElementById('teams-search');
 if(next){next.focus();if(cursor!==null)next.setSelectionRange(cursor,cursor)}
}});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;document.getElementById('install-button').hidden=false});
document.getElementById('install-button').addEventListener('click',async()=>{if(!installPrompt){toast('En Chrome: ⋮ → Instalar aplicación o Añadir a pantalla de inicio');return}await installPrompt.prompt();installPrompt=null;document.getElementById('install-button').hidden=true});
window.addEventListener('appinstalled',()=>toast('LA COOPE instalada correctamente'));
async function bootstrap(){try{
 teams=await fetch('./teams.json').then(r=>r.json());knownGames=[];
 favorite=load(KEY_FAV); selected=load(KEY_VIEW)||MAIN_TEAM;try{const old=JSON.parse(load(DATA_KEY)||'{}');currentSeason=CoopeSeason.normalized(old.season);officialSnapshots=old.snapshots||{}}catch(e){officialSnapshots={}}
 if(!teams.some(t=>t.id===selected))selected=MAIN_TEAM;
 if(!teams.some(t=>t.id===favorite))favorite='';
 render();triggerSync();if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
}catch(err){document.getElementById('view').innerHTML='<div class="card" style="padding:18px"><h2>No se pudieron abrir los datos locales</h2><p>Prueba a publicar o abrir la versión de demostración de LA COOPE.</p></div>';console.error(err)}}
// Las visitas a la web recuperan los datos publicados sin reconstruir la APK.
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&teams.length&&(!feedCheckedAt||Date.now()-Date.parse(feedCheckedAt)>300000))triggerSync()});
window.addEventListener('online',()=>{if(teams.length)triggerSync()});
bootstrap();

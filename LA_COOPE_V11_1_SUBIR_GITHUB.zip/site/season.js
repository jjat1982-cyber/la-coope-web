/* LA COOPE: identificación de temporada y enlaces oficiales FCF. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.CoopeSeason=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function normalized(x){const m=String(x||'').trim().match(/^(20\d{2})\s*[-/]\s*(?:20)?(\d{2,4})$/);if(!m)return null;const a=Number(m[1]),b=Number(m[2].length===2?'20'+m[2]:m[2]);return b===a+1?{label:`${a}/${String(b).slice(-2)}`,slug:`${a}-${b}`,short:`${String(a).slice(-2)}${String(b).slice(-2)}`,start:a}:null}
function officialUrl(url){try{const u=new URL(url);return u.protocol==='https:'&&['www.fcf.cat','fcf.cat'].includes(u.hostname)}catch(e){return false}}
function acceptFeed(feed,previous){const s=normalized(feed?.season);if(!s||feed?.source!=='fcf.cat'||feed?.confirmed!==true||!Array.isArray(feed?.officialEvidence)||!feed.officialEvidence.some(officialUrl))return null;
 const old=normalized(previous);if(old&&s.start<old.start)return null;return s}
function officialSection(url,part){if(!['resultats','calendari','classificacio'].includes(part)||!officialUrl(url))return null;
 // Rutas reales de la FCF: /resultats/2627/futbol-11/primera-catalana/grup-3
 const u=new URL(url);
 const match=u.pathname.match(/^\/(resultats|calendari|classificacio)\/(\d{4}\/futbol-(?:11|7)\/[a-z0-9-]+\/grup-\d+)(?:\/jornada-\d+)?\/?$/i);
 if(match)return `${u.origin}/${part}/${match[2]}`;
 return null}
return{normalized,officialUrl,acceptFeed,officialSection};
});
